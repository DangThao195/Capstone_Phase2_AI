"""
Build a 1-month-ahead (June 2026) forecast TEST dataset for FinOps Watch.

Design goals
------------
* Same three CSV schemas as the historical data (CE / CUR / metrics).
* DIFFERENT accounts / services / regions than the training set, so detection
  success also proves cross-identity generalization (not memorized identities).
* Inject 3 randomly-chosen anomaly types + 1 benign trap, each following exactly
  the scenario SHAPE described for its anomaly_type in the prompt:
     - runaway_usage : new compute, expensive, runs 24/7 incl weekends (no weekend dip)
     - gradual_drift : slow multi-week ratchet-up (mean_7d/mean_28d creeps >1.15)
     - untagged_spend: material daily cost with NO team tag, chronic
     - benign_event  : looks like a spike but SHORT (<5 days) & planned -> must suppress
* A realistic baseline of normal spend so detectors have context to learn from.
"""
import numpy as np
import pandas as pd

RNG = np.random.default_rng(2026)
# The new accounts already exist with normal history; June is the month we watch.
# WARMUP gives spike/drift a real 28d+ baseline (matches production reality where
# an account is not born the same day its anomaly starts). Detection/eval is June.
WARMUP_START = pd.Timestamp("2026-04-27")   # ~35 days of clean baseline
START = pd.Timestamp("2026-06-01")          # forecast month begins
END = pd.Timestamp("2026-06-30")
DATES = pd.date_range(START, END, freq="D")            # anomaly-injection month
BASE_DATES = pd.date_range(WARMUP_START, END, freq="D")  # full emitted range

# ── NEW identities (unseen in training) ─────────────────────────────────────
ACCOUNTS = {
    "300000000021": "eu-platform",
    "300000000022": "apac-web",
    "300000000023": "sandbox-lab",
    "300000000024": "billing-svc",
}
REGION = "eu-west-1"   # different region than training (us-east-1 / us-west-2)

# baseline (normal) service spend per account: (service_code, ce_name, ~daily $, weekend_factor)
BASELINE = [
    ("eu-platform",  "AmazonEC2",   "Amazon Elastic Compute Cloud - Compute", 260, 0.55),
    ("eu-platform",  "AmazonS3",    "Amazon Simple Storage Service",           40, 0.95),
    ("eu-platform",  "AmazonRDS",   "Amazon Relational Database Service",      180, 0.9),
    ("apac-web",     "AmazonEC2",   "Amazon Elastic Compute Cloud - Compute", 210, 0.5),
    ("apac-web",     "AWSDataTransfer", "AWS Data Transfer",                   120, 0.7),
    ("apac-web",     "AmazonCloudFront", "Amazon CloudFront",                   90, 0.85),
    ("sandbox-lab",  "AmazonEC2",   "Amazon Elastic Compute Cloud - Compute",  70, 0.6),
    ("sandbox-lab",  "AmazonElastiCache", "Amazon ElastiCache",                55, 0.9),
    ("billing-svc",  "AmazonDynamoDB", "Amazon DynamoDB",                      140, 0.95),
    ("billing-svc",  "AWSLambda",   "AWS Lambda",                              30, 0.8),
]
ACC_ID = {v: k for k, v in ACCOUNTS.items()}

USAGE_TYPE = {
    "AmazonEC2": ("BoxUsage:m5.2xlarge", "RunInstances", "Hrs", 0.384, "m5.2xlarge"),
    "AmazonS3": ("TimedStorage-ByteHrs", "StandardStorage", "GB-Mo", 0.023, ""),
    "AmazonRDS": ("InstanceUsage:db.r5.xlarge", "CreateDBInstance", "Hrs", 0.58, "db.r5.xlarge"),
    "AWSDataTransfer": ("DataTransfer-Out-Bytes", "PublicIP-Out", "GB", 0.09, ""),
    "AmazonCloudFront": ("Requests-Tier1", "GET", "Requests", 0.0000075, ""),
    "AmazonElastiCache": ("NodeUsage:cache.r6g.large", "CreateCacheCluster", "Hrs", 0.226, "cache.r6g.large"),
    "AmazonDynamoDB": ("WriteCapacityUnit-Hrs", "PayPerRequestThroughput", "WCU-Hrs", 0.00065, ""),
    "AWSLambda": ("Lambda-GB-Second", "Invoke", "seconds", 0.0000166667, ""),
    "AmazonSageMaker": ("Host:ml.p3.2xlarge", "RunInstances", "Hrs", 3.06, "ml.p3.2xlarge"),
    "AmazonCloudWatch": ("DataProcessing-Bytes", "PutLogEvents", "GB", 0.50, ""),
}

TEAMS = {"eu-platform": "platform", "apac-web": "web",
         "sandbox-lab": "labs", "billing-svc": "billing"}


def _wk(d):  # weekend?
    return d.dayofweek >= 5


ce_rows, cur_rows, met_rows, labels = [], [], [], []
_rid = [1000]
def nid(pfx):
    _rid[0] += 1
    return f"{pfx}-{_rid[0]}"


def emit(acc, svc, ce_name, date, cost, resource_id, team, inst="",
         usage_amount=None, metrics=None, region=REGION):
    """Write one CE row + one CUR row (+ optional metric rows) for a resource-day."""
    ut, op, unit, rate, deftype = USAGE_TYPE[svc]
    inst = inst or deftype
    if usage_amount is None:
        usage_amount = cost / rate if rate else cost
    ce_rows.append(dict(date=date, linked_account_id=ACC_ID[acc], linked_account_name=acc,
                        service=ce_name, service_code=svc, region=region,
                        unblended_cost=round(cost, 4), is_estimated=(date >= END - pd.Timedelta(days=1))))
    cur_rows.append(dict(
        bill_billing_period_start_date="2026-06-01T00:00:00Z",
        bill_payer_account_id="100000000001",
        line_item_usage_account_id=ACC_ID[acc], line_item_usage_account_name=acc,
        line_item_line_item_type="Usage",
        line_item_usage_start_date=date.strftime("%Y-%m-%dT00:00:00Z"),
        line_item_usage_end_date=(date + pd.Timedelta(days=1)).strftime("%Y-%m-%dT00:00:00Z"),
        line_item_product_code=svc, line_item_usage_type=ut, line_item_operation=op,
        line_item_resource_id=resource_id, line_item_usage_amount=round(usage_amount, 4),
        pricing_unit=unit, line_item_unblended_rate=rate,
        line_item_unblended_cost=round(cost, 4), line_item_currency_code="USD",
        product_product_name=ce_name, product_region_code=region,
        product_instance_type=inst, resource_tags_user_team=team,
        resource_tags_user_environment="prod", resource_tags_user_cost_center="CC-2001",
        resource_tags_user_owner=""))
    if metrics:
        for mname, mval, munit in metrics:
            met_rows.append(dict(timestamp=date.strftime("%Y-%m-%dT00:00Z"),
                                 resource_id=resource_id, service=svc,
                                 account_id=ACC_ID[acc], metric_name=mname,
                                 metric_value=mval, unit=munit,
                                 is_anomaly=False, anomaly_type="normal"))


# ── 1) BASELINE normal spend (each service = a couple of healthy resources) ──
base_res_ids = {}
for acc, svc, ce_name, daily, wkf in BASELINE:
    n_res = 2
    ids = [nid(f"res-{svc.lower()}") for _ in range(n_res)]
    base_res_ids[(acc, svc)] = ids
    for d in BASE_DATES:
        w = wkf if _wk(d) else 1.0
        for rid in ids:
            noise = RNG.normal(1.0, 0.06)
            cost = max(1.0, daily / n_res * w * noise)
            mets = None
            if svc == "AmazonEC2":
                mets = [("CPUUtilization", float(np.clip(RNG.normal(45, 10), 5, 95)), "Percent")]
            elif svc == "AmazonRDS":
                mets = [("CPUUtilization", float(np.clip(RNG.normal(40, 8), 5, 90)), "Percent"),
                        ("DatabaseConnections", float(np.clip(RNG.normal(90, 20), 10, 200)), "Count")]
            elif svc == "AmazonElastiCache":
                mets = [("CPUUtilization", float(np.clip(RNG.normal(35, 8), 5, 80)), "Percent")]
            emit(acc, svc, ce_name, d, cost, rid, TEAMS[acc], metrics=mets)


# ═══════════════════════════════════════════════════════════════════════════
# 2) INJECT ANOMALIES  (chosen types: runaway_usage, gradual_drift, untagged_spend)
# ═══════════════════════════════════════════════════════════════════════════

# ── T1 runaway_usage : NEW SageMaker GPU cluster in sandbox-lab, runs 24/7 ──
# scenario: training cluster spun up mid-month, never shut down, incl weekends.
run_start, run_end = pd.Timestamp("2026-06-10"), pd.Timestamp("2026-06-27")
run_ids = [f"i-0fbtrain00000{i}" for i in range(4)]   # NOTE: EC2 GPU instances
for rid in run_ids:
    for d in DATES:
        if run_start <= d <= run_end:
            cost = 3.06 * 24 * RNG.normal(1.0, 0.01)   # p3.2xlarge 24h, no weekend dip
            emit("sandbox-lab", "AmazonEC2",
                 "Amazon Elastic Compute Cloud - Compute", d, cost, rid, "labs",
                 inst="p3.2xlarge",
                 metrics=[("GPUUtilization", float(np.clip(RNG.normal(88, 5), 60, 99)), "Percent"),
                          ("CPUUtilization", float(np.clip(RNG.normal(70, 8), 40, 95)), "Percent")])
for rid in run_ids:
    labels.append(dict(anomaly_id="T1", label="anomaly", anomaly_type="runaway_usage",
                       linked_account_id=ACC_ID["sandbox-lab"], linked_account_name="sandbox-lab",
                       service="AmazonEC2", resource_id=rid,
                       start_date=run_start.date(), end_date=run_end.date(),
                       approx_daily_cost=73.44, approx_total_cost=73.44*4,
                       description="GPU training cluster left running 24/7 incl weekends."))

# ── T2 gradual_drift : DynamoDB write-capacity ratchet in billing-svc ────────
# scenario: provisioned WCU flat during baseline, then creeps up all June.
drift_start, drift_end = pd.Timestamp("2026-06-01"), pd.Timestamp("2026-06-30")
drift_rid = nid("ddb-billing-events")
lo, hi = 70.0, 360.0
for d in BASE_DATES:
    if d < START:
        level = lo                                    # flat baseline pre-June
    else:
        frac = (d - START).days / (len(DATES) - 1)
        level = lo + (hi - lo) * frac                 # slow linear ramp in June
    cost = level * RNG.normal(1.0, 0.05)
    emit("billing-svc", "AmazonDynamoDB", "Amazon DynamoDB", d, cost, drift_rid,
         "billing",
         metrics=[("ProvisionedWriteCapacityUnits", level*1.2, "Count"),
                  ("ConsumedWriteCapacityUnits", level*0.9, "Count")])
labels.append(dict(anomaly_id="T2", label="anomaly", anomaly_type="gradual_drift",
                   linked_account_id=ACC_ID["billing-svc"], linked_account_name="billing-svc",
                   service="AmazonDynamoDB", resource_id=drift_rid,
                   start_date=drift_start.date(), end_date=drift_end.date(),
                   approx_daily_cost="70->360", approx_total_cost=6000,
                   description="Provisioned write capacity ratchets up, never scales down."))

# ── T3 untagged_spend : chronic untagged EC2 fleet in eu-platform ────────────
untag_rid = nid("i-0untaggedfleet")
for d in DATES:
    cost = 165.0 * RNG.normal(1.0, 0.05)              # material, chronic
    emit("eu-platform", "AmazonEC2", "Amazon Elastic Compute Cloud - Compute",
         d, cost, untag_rid, team=None, inst="m5.4xlarge",   # NO team tag
         metrics=[("CPUUtilization", float(np.clip(RNG.normal(55, 10), 20, 95)), "Percent")])
labels.append(dict(anomaly_id="T3", label="anomaly", anomaly_type="untagged_spend",
                   linked_account_id=ACC_ID["eu-platform"], linked_account_name="eu-platform",
                   service="AmazonEC2", resource_id=untag_rid,
                   start_date=START.date(), end_date=END.date(),
                   approx_daily_cost=165.0, approx_total_cost=165*30,
                   description="Untagged m5.4xlarge fleet - unattributable spend."))

# ── B benign_event : planned 3-day CloudFront/DataTransfer campaign (SHORT) ──
# scenario: pre-approved marketing campaign, big egress for 3 days, then normal.
ben_start, ben_end = pd.Timestamp("2026-06-18"), pd.Timestamp("2026-06-20")
ben_rid = nid("dt-campaign-egress")
for d in DATES:
    if ben_start <= d <= ben_end:
        cost = 700.0 * RNG.normal(1.0, 0.04)          # looks like a spike...
        emit("apac-web", "AWSDataTransfer", "AWS Data Transfer", d, cost, ben_rid, "web")
labels.append(dict(anomaly_id="B", label="benign", anomaly_type="benign_event",
                   linked_account_id=ACC_ID["apac-web"], linked_account_name="apac-web",
                   service="AWSDataTransfer", resource_id=ben_rid,
                   start_date=ben_start.date(), end_date=ben_end.date(),
                   approx_daily_cost=700.0, approx_total_cost=2100,
                   description="Planned 3-day marketing campaign egress - pre-approved, NOT an anomaly."))

# ── write files ─────────────────────────────────────────────────────────────
import os
OUT = "/home/claude/forecast_data"
os.makedirs(OUT, exist_ok=True)
pd.DataFrame(ce_rows).to_csv(f"{OUT}/cost_explorer_daily.csv", index=False)
pd.DataFrame(cur_rows).to_csv(f"{OUT}/cur_line_items.csv", index=False)
pd.DataFrame(met_rows).to_csv(f"{OUT}/metrics.csv", index=False)
pd.DataFrame(labels).to_csv(f"{OUT}/anomaly_labels_full.csv", index=False)

print("Forecast dataset written to", OUT)
print("CE rows:", len(ce_rows), "| CUR rows:", len(cur_rows), "| metric rows:", len(met_rows))
print("Accounts:", list(ACCOUNTS.values()))
print("Injected:", sorted(set((l['anomaly_id'], l['anomaly_type'], l['label']) for l in labels)))
