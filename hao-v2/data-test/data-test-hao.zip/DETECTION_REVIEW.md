# FinOps Watch — Nhận xét kết quả detect (Forecast tháng 6/2026)

*Pipeline: hybrid statistical ensemble + IsolationForest, 2 grain (panel account×service, resource×day), 100% identity-free ở tầng ML.*

---

## 1. Tóm tắt điều hành

Pipeline được **fit một lần** trên dữ liệu backtest 3 tháng (Mar–May 2026), đóng băng model, rồi chạy **detect theo nhịp 24 giờ** trên tháng dự báo (Jun 2026) — một tập dữ liệu hoàn toàn mới với **4 account chưa từng xuất hiện** trong training (`eu-platform`, `apac-web`, `sandbox-lab`, `billing-svc`, region `eu-west-1`).

| Chỉ số | Backtest (Mar–May) | Forecast (Jun) |
|---|---|---|
| Precision | 1.00 | **1.00** |
| Recall | 1.00 | **1.00** |
| F1 | 1.00 | **1.00** |
| FPR | 0.00 | **0.00** |

Kết quả: **3/3 anomaly được phát hiện đúng loại, 1/1 benign bị suppress đúng.** Vượt yêu cầu cứng của đề bài (Precision ≥ 80%, FPR ≤ 10%).

---

## 2. Model có thực sự học pattern không? — Có.

Ba bằng chứng độc lập:

1. **Generalization Test (PASS).** Ẩn danh toàn bộ account → `acct-A/B…` và service → `svc-1/2…`, vector detect và mọi metric **giống hệt** bản gốc (P/R/F1 = 1.0). Nếu model dựa vào danh tính, đổi tên sẽ phá kết quả — nó không phá. → model học *hành vi*, không học *danh tính*.

2. **Cross-identity forecast (PASS).** Tháng 6 dùng account/region chưa từng thấy. Model vẫn detect đúng dù không có bất kỳ danh tính nào để "nhớ". Đây là kiểm chứng mạnh nhất: pattern được học mang tính *bất biến theo shape*, không phải lookup table.

3. **Không có feature định danh ở tầng ML.** account_id / resource_id / service_name **không** được đưa vào IsolationForest. Model chỉ thấy động lực học chuỗi thời gian (spike_ratio, drift_ratio, cusum, STL residual…) + tiện ích riêng của resource (weekend_ratio, GPU/CPU util). Đây chính là cách vá lỗi identity-overfitting (P/R/F1 = 0 trên holdout) đã gặp trước đó.

---

## 3. Kết quả detect theo sự kiện (Jun 2026)

| ID | Loại (thực tế) | Detect | Loại (dự đoán) | First alert | Delay | Confidence |
|---|---|---|---|---|---|---|
| T1 | runaway_usage | ✅ | runaway_usage | 14/06 | +4d | HIGH |
| T2 | gradual_drift | ✅ | gradual_drift | 22/06 | +21d | HIGH |
| T3 | untagged_spend | ✅ | untagged_spend | 03/06 | +2d | HIGH |
| B  | benign_event | ✅ suppress | — | — | — | — |

**Loại dự đoán khớp 100% với loại thực tế** — không chỉ "có phát hiện" mà còn phân loại đúng root cause.

---

## 4. Nhận xét từng ca

### T1 — runaway_usage (GPU cluster chạy 24/7, sandbox-lab)
Phát hiện ở **resource grain**: 4 instance `i-0fbtrain00000X` bật cả cuối tuần (`weekend_ratio ≈ 1.0`, không có nhịp giảm cuối tuần) + GPU util cao + chi phí lớn, scope đúng vào compute (AmazonEC2). Delay +4d là hợp lý: cần đủ ngày (bao gồm 1 cuối tuần) để chứng minh "không có weekend dip". Alert HIGH, chỉ đích danh 4 resource → hành động được ngay.

### T2 — gradual_drift (DynamoDB WCU ratchet, billing-svc)
Đây là ca **khó nhất** và delay dài nhất (+21d) — đúng bản chất drift: tăng chậm tuyến tính $70→$360, mỗi ngày chỉ nhích ~1.15×. Rule yêu cầu drift bền vững ≥14 ngày mới fire, nên first-alert rơi vào 22/06. Đây là *đánh đổi có chủ đích*: hạ ngưỡng để bắt sớm hơn sẽ kéo theo nhiễu. Với drift, phát hiện chắc chắn quan trọng hơn phát hiện sớm.

### T3 — untagged_spend (fleet m5.4xlarge không tag, eu-platform)
Nhanh nhất (+2d). Phát hiện ở resource grain: fleet có chi phí đáng kể nhưng `team = None`, kéo dài. Chỉ cần vài ngày để vượt ngưỡng chronic → alert HIGH đích danh resource. Đây là loại "tiền rò rỉ âm thầm" mà detect sớm tiết kiệm trực tiếp.

### B — benign_event (chiến dịch marketing 3 ngày, apac-web)
**Suppress đúng.** Egress tăng vọt ~$700/ngày trông y hệt một spike, nhưng chỉ kéo dài 3 ngày (< ngưỡng 5 ngày). Business rule "spike phải bền vững ≥5 ngày mới là anomaly" lọc chính xác trap này — cùng logic đã suppress B1/B2/B3 ở backtest. Đây là điểm phân biệt một detector *dùng được* với một detector *spam alert*.

---

## 5. Điểm cần lưu ý: alert đa-grain (corroboration, không phải nhiễu)

Log 24h có thêm vài dòng panel-level:
- `eu-platform/AmazonEC2` → spike (05/06) + drift (16/06)
- `sandbox-lab/AmazonEC2` → spike (14/06) + drift (24/06)

Đây **không phải false positive**. Chúng là *bóng* của chính T1 và T3 ở grain account×service: chi phí resource bất thường bị "chảy" lên mức panel của cùng account/service đó. Bộ chấm điểm event-level quy đúng chúng về T1/T3 (nên FPR vẫn = 0). Trong vận hành thực tế, đây là **tín hiệu xác nhận chéo** đáng giữ: một vấn đề chi phí lộ diện ở cả 2 grain thì độ tin cậy cao hơn. Nếu muốn gọn log, có thể gộp alert theo (account, service) khi resource-grain alert đã tồn tại — nhưng không nên *xoá* tín hiệu panel.

---

## 6. Vá lỗi quan trọng trong lần chạy này: cold-start guard

Lần chạy đầu tiên trên forecast sinh ra **một loạt alert giả** ngày 05/06 và 15/06 trên gần như mọi account×service, và benign B bị bắt nhầm thành drift → Precision tụt còn 0.75.

**Nguyên nhân:** các account tháng 6 là *hoàn toàn mới*, nên baseline 28 ngày khởi động từ ~0. Cả tháng đầu tiên trông như một cú level-shift/drift khổng lồ (cold-start artifact).

**Cách vá (đúng kiểu production):** thêm `PANEL_MIN_HISTORY = 28` — rule spike/drift ở panel chỉ được kích hoạt sau khi account×service có đủ ≥28 ngày lịch sử. Đồng thời dataset forecast được cấp **~35 ngày warm-up sạch** trước tháng 6 (account tồn tại từ trước, tháng 6 mới là tháng "theo dõi"). Sau khi vá: FPR về 0, benign suppress đúng, backtest và generalization test **không bị ảnh hưởng** (mọi group backtest đều có 92 ngày lịch sử).

Bài học: detector chuỗi thời gian **phải** có warm-up guard; nếu không, mọi entity mới sinh ra sẽ tự động là "anomaly".

---

## 7. Kết luận

- Pipeline generalize thật: chứng minh qua cả anonymization test lẫn cross-identity forecast trên account chưa từng thấy.
- Trên tháng dự báo: **P/R/F1 = 1.0, FPR = 0**, phân loại đúng cả 3 loại anomaly, suppress đúng benign.
- Đánh đổi delay là có chủ đích và hợp lý theo từng loại (untagged nhanh, drift chậm).
- Điểm cải thiện tiếp theo (tuỳ nhu cầu): (a) gộp alert đa-grain cho gọn dashboard; (b) thêm ước lượng "$ lãng phí tích luỹ" vào mỗi alert để ưu tiên xử lý; (c) cân nhắc hạ nhẹ ngưỡng drift-sustained nếu muốn rút ngắn delay của loại gradual_drift.
