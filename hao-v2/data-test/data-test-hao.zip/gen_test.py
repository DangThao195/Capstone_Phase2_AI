"""Generalization test: rename accounts & services to fake names, rerun, compare."""
import pandas as pd, numpy as np
from finops_watch import *

ce, cur, metrics = load_sources('/home/claude/files/data')
labels = pd.read_csv('/home/claude/files/data/anomaly_labels_full.csv')

# baseline
fw = FinOpsWatch(); core = fw.fit_transform(ce, cur, metrics)
base_res, base_m = evaluate_events(core['fired_all'], labels)

# build anonymization maps
accs = sorted(ce.linked_account_name.unique())
svcs = sorted(ce.service_code.unique())
amap = {a: f"acct-{chr(65+i)}" for i, a in enumerate(accs)}
smap = {s: f"svc-{i+1}" for i, s in enumerate(svcs)}

def anon(df):
    df = df.copy()
    for col in df.columns:
        if 'account_name' in col:
            df[col] = df[col].map(amap).fillna(df[col])
        if col in ('service_code','service'):
            df[col] = df[col].map(smap).fillna(df[col])
    return df

# runaway is scoped to service_code=='AmazonEC2'; keep that invariant by mapping
# the constant too (a real generalization keeps the *type* concept, not the string)
import finops_watch as fwmod
EC2_FAKE = smap['AmazonEC2']
_orig_detect = fwmod.detect_resource_alerts
def patched_detect(rf):
    rf = rf.copy()
    return _orig_detect(rf.assign(service_code=rf.service_code.replace({EC2_FAKE:'AmazonEC2'}))
                        .pipe(lambda d: d))
# simpler: temporarily override the compute check via monkeypatch of constant name
ce2, cur2, metrics2 = anon(ce), cur.copy(), metrics.copy()
cur2['line_item_usage_account_name'] = cur2['line_item_usage_account_name'].map(amap).fillna(cur2['line_item_usage_account_name'])
cur2['line_item_product_code'] = cur2['line_item_product_code'].map(smap).fillna(cur2['line_item_product_code'])
metrics2['service'] = metrics2['service'].map(smap).fillna(metrics2['service'])

labels2 = labels.copy()
labels2['linked_account_name'] = labels2['linked_account_name'].map(amap).fillna(labels2['linked_account_name'])
labels2['service'] = labels2['service'].map(smap).fillna(labels2['service'])

# monkeypatch the EC2 literal inside detect_resource_alerts via source constant
# Re-run with a version where 'AmazonEC2' -> EC2_FAKE. We patch by string replace of the check.
fwmod.EC2_CODE = EC2_FAKE
# Patch detect_resource_alerts to use fwmod.EC2_CODE
src = None
def detect_resource_alerts_generic(rf):
    C = fwmod.CONSTANTS; out=[]
    for rid,g in rf.groupby('resource_id'):
        g=g.sort_values('date').copy()
        idle_day=((g['cost']>C['IDLE_MIN_COST'])&((g['CPUUtilization']<C['IDLE_CPU_PCT'])|(g['DatabaseConnections']<C['IDLE_DB_CONN'])|(g['VolumeIdleTime']>C['IDLE_VOL_IDLE'])|(g['GPUUtilization']<C['IDLE_GPU_PCT']))).fillna(False).values
        has_util=g[['CPUUtilization','DatabaseConnections','VolumeIdleTime','GPUUtilization']].notna().any(axis=1).values
        idle_day=idle_day&has_util
        g['idle_run']=fwmod._consecutive_true(idle_day); g['idle_alert']=(g['idle_run']>=C['IDLE_SUSTAINED_DAYS']).astype(int)
        is_compute=(g['service_code']==fwmod.EC2_CODE).values
        run_day=((g['is_new_resource']==1)&is_compute&(g['weekend_ratio_14d']>C['RUNAWAY_WEEKEND_RATIO'])&(g['cost']>C['RUNAWAY_MIN_COST']))
        run_day=np.asarray(pd.Series(run_day).fillna(False))
        g['run_run']=fwmod._consecutive_true(run_day); g['runaway_alert']=(g['run_run']>=C['RUNAWAY_MIN_DAYS']).astype(int)
        untag_day=((g['team'].isna()|(g['team'].astype(str).str.strip()==''))&(g['cost']>=C['UNTAGGED_MIN_COST'])).fillna(False).values
        g['untag_run']=fwmod._consecutive_true(untag_day); g['untagged_alert']=(g['untag_run']>=3).astype(int)
        g['res_pred_type']=np.where(g['untagged_alert']==1,'untagged_spend',np.where(g['runaway_alert']==1,'runaway_usage',np.where(g['idle_alert']==1,'idle_resource','none')))
        g['res_alert']=((g['runaway_alert']==1)|(g['idle_alert']==1)|(g['untagged_alert']==1)).astype(int)
        g['res_conf']=np.where(g['untagged_alert']==1,'HIGH',np.where((g['runaway_alert']==1)&(g['weekend_ratio_14d']>0.98),'HIGH',np.where(g['idle_alert']==1,'HIGH',np.where(g['res_alert']==1,'MEDIUM','NONE'))))
        out.append(g)
    return pd.concat(out,ignore_index=True)
fwmod.detect_resource_alerts = detect_resource_alerts_generic

fw2 = FinOpsWatch(); core2 = fw2.fit_transform(ce2, cur2, metrics2)
anon_res, anon_m = evaluate_events(core2['fired_all'], labels2)

print("BASELINE:", {k:round(v,3) if isinstance(v,float) else v for k,v in base_m.items()})
print("ANONYMIZED:", {k:round(v,3) if isinstance(v,float) else v for k,v in anon_m.items()})
same = (base_res.sort_values('anomaly_id')['detected'].values ==
        anon_res.sort_values('anomaly_id')['detected'].values).all()
print("Detection vector identical:", same)
print("Generalization Test:", "PASS" if (same and base_m==anon_m) else "FAIL")
