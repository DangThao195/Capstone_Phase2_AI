"""
FinOps Watch — Unsupervised Hybrid Anomaly Detection Pipeline (v2)
==================================================================
Production-grade, non-overfit cost anomaly detector for AWS multi-account bills.

Two detection grains (both identity-free for ML):
  * PANEL grain  (account x service x day)   -> sudden_spike, gradual_drift, untagged
  * RESOURCE grain (resource x day)          -> runaway_usage, idle_resource
Resource grain is required because idle/runaway anomalies are single-resource
events that get averaged away at account x service aggregation (the exact
"account-level labeling" failure mode called out in the prompt).

Key design guarantees
---------------------
* No account_id / resource_id / service_name enters any ML model. Only behavioral
  dynamics + continuous frequency priors. Detection is threshold- & shape-based.
* sudden_spike uses a LEVEL-SHIFT vs pre-spike baseline sustained >= 5 days, which
  suppresses benign B1(4d)/B2(3d)/B3(2d) planned events by business logic.
* runaway = new resource + weekend_ratio ~1.0 (no weekend dip) + material cost.
* idle = resource's own utilization metric ~0 while it keeps costing money >=14d.
* Evaluation is EVENT-LEVEL. Daily persistence filter (N=2) kills single-day noise.
* Fitted IF models are reusable via `.transform()` for forward (out-of-sample) tests.
"""

from __future__ import annotations
import warnings
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from statsmodels.tsa.seasonal import STL
from sklearn.ensemble import IsolationForest

warnings.filterwarnings("ignore")

# ────────────────────────────────────────────────────────────────────────────
# SECTION 0 — CONSTANTS
# ────────────────────────────────────────────────────────────────────────────
CONSTANTS = {
    "RANDOM_STATE": 42,
    "ROLL_7": 7, "ROLL_14": 14, "ROLL_28": 28,
    "STD_FLOOR": 0.5,
    "SPIKE_RATIO": 1.6,
    "SPIKE_MIN_ABS": 100.0,
    "SPIKE_SUSTAINED_DAYS": 5,   # NOTE: >=5d filters benign B1(4)/B2(3)/B3(2)
    "ROBUST_Z_HARD": 3.5,
    "DRIFT_RATIO": 1.15,
    "DRIFT_SUSTAINED_DAYS": 14,
    "CUSUM_K_STD": 5.0,
    "UNTAGGED_MIN_COST": 30.0,
    "IDLE_CPU_PCT": 5.0,
    "IDLE_DB_CONN": 5.0,
    "IDLE_VOL_IDLE": 80.0,
    "IDLE_GPU_PCT": 5.0,
    "IDLE_MIN_COST": 5.0,
    "IDLE_SUSTAINED_DAYS": 14,
    "RUNAWAY_WEEKEND_RATIO": 0.92,
    "RUNAWAY_MIN_COST": 40.0,
    "NEW_RESOURCE_MIN_DAY": 7,
    "RUNAWAY_MIN_DAYS": 5,
    # Panel spike/drift need a real baseline before they can fire. A brand-new
    # account x service (cold start) has no 28d history, so its first weeks would
    # otherwise read as one giant level-shift/drift. Require >= this many prior
    # observed days in the group before panel rules are eligible.
    "PANEL_MIN_HISTORY": 28,
    "IF_CONTAM_SPIKE": 0.02, "IF_CONTAM_DRIFT": 0.03,
    "IF_SCORE_HI": 0.70,
    "PERSISTENCE_N": 2,
    "GRACE_DAYS": 2,
}


def _consecutive_true(flags) -> np.ndarray:
    flags = np.asarray(flags); out = np.zeros(len(flags), dtype=int); run = 0
    for i, f in enumerate(flags):
        run = run + 1 if f else 0
        out[i] = run
    return out


def _cusum_pos(x, ref) -> np.ndarray:
    out = np.zeros(len(x)); acc = 0.0
    for i in range(len(x)):
        d = x[i] - ref[i]
        acc = max(0.0, acc + (0 if np.isnan(d) else d)); out[i] = acc
    return out


def _norm(raw):
    lo, hi = np.nanmin(raw), np.nanmax(raw)
    return (raw - lo) / (hi - lo) if hi > lo else np.zeros_like(raw)


# ─── SECTION 1 — INGESTION ──────────────────────────────────────────────────
def load_sources(data_dir: str):
    ce = pd.read_csv(f"{data_dir}/cost_explorer_daily.csv", parse_dates=["date"])
    cur = pd.read_csv(f"{data_dir}/cur_line_items.csv")
    cur["date"] = pd.to_datetime(cur["line_item_usage_start_date"], utc=True).dt.tz_localize(None).dt.normalize()
    try:
        metrics = pd.read_csv(f"{data_dir}/metrics.csv")
        metrics["timestamp"] = pd.to_datetime(metrics["timestamp"], utc=True).dt.tz_localize(None)
        metrics["date"] = metrics["timestamp"].dt.normalize()
    except FileNotFoundError:
        metrics = pd.DataFrame(columns=["date", "resource_id", "service",
                                        "account_id", "metric_name", "metric_value"])
    return ce, cur, metrics


def build_panel(ce: pd.DataFrame) -> pd.DataFrame:
    df = (ce.groupby(["linked_account_name", "service_code", "date"], as_index=False)
            .agg(cost=("unblended_cost", "sum"),
                 is_estimated=("is_estimated", "max"),
                 region=("region", "first")))
    cal = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
    out = []
    for (acc, svc), g in df.groupby(["linked_account_name", "service_code"]):
        g = g.set_index("date").reindex(cal)
        g["linked_account_name"] = acc; g["service_code"] = svc
        g["cost"] = g["cost"].fillna(0.0)
        g["is_estimated"] = g["is_estimated"].fillna(False)
        g["region"] = g["region"].ffill().bfill()
        out.append(g.rename_axis("date").reset_index())
    return (pd.concat(out, ignore_index=True)
            .sort_values(["linked_account_name", "service_code", "date"])
            .reset_index(drop=True))


# ─── SECTION 2 — PANEL FEATURES (spike / drift) ─────────────────────────────
def engineer_panel_features(panel: pd.DataFrame, cur: pd.DataFrame) -> pd.DataFrame:
    C = CONSTANTS
    acc_freq = (panel.groupby("linked_account_name").size() / len(panel)).to_dict()
    svc_freq = (panel.groupby("service_code").size() / len(panel)).to_dict()
    rows = []
    for (acc, svc), g in panel.groupby(["linked_account_name", "service_code"]):
        g = g.sort_values("date").copy(); c = g["cost"].astype(float)
        g["rolling_mean_7d"] = c.shift(1).rolling(C["ROLL_7"], min_periods=1).mean()
        g["rolling_std_7d"] = c.shift(1).rolling(C["ROLL_7"], min_periods=1).std()
        g["rolling_mean_28d"] = c.shift(1).rolling(C["ROLL_28"], min_periods=1).mean()
        g["rolling_median_28d"] = c.shift(1).rolling(C["ROLL_28"], min_periods=1).median()
        g["lag_1"] = c.shift(1); g["lag_7"] = c.shift(7)
        g["ewma_7"] = c.shift(1).ewm(span=C["ROLL_7"]).mean()
        std_clip = g["rolling_std_7d"].clip(lower=C["STD_FLOOR"]).fillna(C["STD_FLOOR"])
        g["robust_z_score"] = (c - g["rolling_median_28d"]) / std_clip
        g["rate_of_change"] = c.pct_change(1).replace([np.inf, -np.inf], np.nan)
        g["delta"] = c - g["rolling_mean_7d"]
        g["pct_rank_30d"] = c.rolling(30, min_periods=3).apply(
            lambda w: (w[-1] >= w).mean(), raw=True)
        base = g["rolling_median_28d"].copy()
        base = base.where(base > 1.0, c.shift(1).expanding().mean())
        g["spike_ratio"] = c / base.clip(lower=1.0)
        g["drift_ratio"] = g["rolling_mean_7d"] / g["rolling_mean_28d"].clip(lower=1.0)
        drift_flag = (g["drift_ratio"] > C["DRIFT_RATIO"]).fillna(False).values
        g["drift_sustained_days"] = _consecutive_true(drift_flag)
        g["cusum_pos"] = _cusum_pos(c.values, g["rolling_median_28d"].fillna(c).values)
        g["account_freq"] = acc_freq.get(acc, 0.0)
        g["service_freq"] = svc_freq.get(svc, 0.0)
        g["stl_residual"] = 0.0; g["stl_trend"] = c.values
        if len(g) >= 2 * C["ROLL_7"] and c.std() > 1e-6:
            try:
                res = STL(c.values, period=C["ROLL_7"], robust=True).fit()
                g["stl_residual"] = res.resid; g["stl_trend"] = res.trend
            except Exception:
                pass
        rows.append(g)
    feat = pd.concat(rows, ignore_index=True)

    cur_ = cur.copy()
    cur_["untagged"] = (cur_["resource_tags_user_team"].isna() |
                        (cur_["resource_tags_user_team"].astype(str).str.strip() == ""))
    untag = (cur_[cur_["untagged"]]
             .groupby(["line_item_usage_account_name", "line_item_product_code", "date"])
             ["line_item_unblended_cost"].sum().rename("untagged_cost").reset_index()
             .rename(columns={"line_item_usage_account_name": "linked_account_name",
                              "line_item_product_code": "service_code"}))
    feat = feat.merge(untag, on=["linked_account_name", "service_code", "date"], how="left")
    feat["untagged_cost"] = feat["untagged_cost"].fillna(0.0)
    return feat


# ─── SECTION 3 — RESOURCE FEATURES (runaway / idle) ─────────────────────────
def build_resource_metric_daily(metrics: pd.DataFrame) -> pd.DataFrame:
    if metrics.empty:
        return pd.DataFrame(columns=["resource_id", "date"])
    keep = ["CPUUtilization", "DatabaseConnections", "VolumeIdleTime",
            "GPUUtilization", "MemoryUtilization"]
    m = metrics[metrics["metric_name"].isin(keep)]
    piv = (m.groupby(["resource_id", "date", "metric_name"])["metric_value"].mean()
             .unstack("metric_name").reset_index())
    return piv


def engineer_resource_features(cur: pd.DataFrame, rmet: pd.DataFrame) -> pd.DataFrame:
    C = CONSTANTS
    r = (cur.groupby(["line_item_usage_account_name", "line_item_product_code",
                      "line_item_resource_id", "date"], as_index=False)
            .agg(cost=("line_item_unblended_cost", "sum"),
                 team=("resource_tags_user_team", "first")))
    r = r.rename(columns={"line_item_usage_account_name": "linked_account_name",
                          "line_item_product_code": "service_code",
                          "line_item_resource_id": "resource_id"})
    dataset_day0 = r["date"].min()
    rows = []
    for rid, g in r.groupby("resource_id"):
        g = g.sort_values("date").copy(); c = g["cost"].astype(float)
        g["is_weekend"] = g["date"].dt.dayofweek >= 5
        vals = c.values; wke = g["is_weekend"].values
        wr = []
        for i in range(len(g)):
            lo = max(0, i - C["ROLL_14"] + 1)
            w, e = vals[lo:i+1], wke[lo:i+1]
            wd, we = w[~e], w[e]
            wr.append(we.mean()/wd.mean() if len(we) and len(wd) and wd.mean() > 0 else np.nan)
        g["weekend_ratio_14d"] = wr
        first_day = g["date"].min()
        g["resource_age_days"] = (g["date"] - first_day).dt.days
        g["is_new_resource"] = int((first_day - dataset_day0).days >= C["NEW_RESOURCE_MIN_DAY"])
        rows.append(g)
    rf = pd.concat(rows, ignore_index=True)
    if not rmet.empty:
        rf = rf.merge(rmet, on=["resource_id", "date"], how="left")
    for col in ["CPUUtilization", "DatabaseConnections", "VolumeIdleTime",
                "GPUUtilization", "MemoryUtilization"]:
        if col not in rf:
            rf[col] = np.nan
    return rf


def detect_resource_alerts(rf: pd.DataFrame):
    C = CONSTANTS; out = []
    for rid, g in rf.groupby("resource_id"):
        g = g.sort_values("date").copy()
        idle_day = (
            (g["cost"] > C["IDLE_MIN_COST"]) &
            ((g["CPUUtilization"] < C["IDLE_CPU_PCT"]) |
             (g["DatabaseConnections"] < C["IDLE_DB_CONN"]) |
             (g["VolumeIdleTime"] > C["IDLE_VOL_IDLE"]) |
             (g["GPUUtilization"] < C["IDLE_GPU_PCT"]))
        ).fillna(False).values
        has_util = g[["CPUUtilization", "DatabaseConnections",
                      "VolumeIdleTime", "GPUUtilization"]].notna().any(axis=1).values
        idle_day = idle_day & has_util
        g["idle_run"] = _consecutive_true(idle_day)
        g["idle_alert"] = (g["idle_run"] >= C["IDLE_SUSTAINED_DAYS"]).astype(int)

        is_compute = (g["service_code"] == "AmazonEC2").values
        run_day = (
            (g["is_new_resource"] == 1) & is_compute &
            (g["weekend_ratio_14d"] > C["RUNAWAY_WEEKEND_RATIO"]) &
            (g["cost"] > C["RUNAWAY_MIN_COST"])
        )
        run_day = np.asarray(pd.Series(run_day).fillna(False))
        g["run_run"] = _consecutive_true(run_day)
        g["runaway_alert"] = (g["run_run"] >= C["RUNAWAY_MIN_DAYS"]).astype(int)

        # UNTAGGED at resource grain: this resource has no team tag & material cost,
        # sustained. Resource grain (not panel) so a tagged flash-sale resource in
        # the same account/service is NOT swept up as untagged.
        untag_day = (
            (g["team"].isna() | (g["team"].astype(str).str.strip() == "")) &
            (g["cost"] >= C["UNTAGGED_MIN_COST"])
        ).fillna(False).values
        g["untag_run"] = _consecutive_true(untag_day)
        g["untagged_alert"] = (g["untag_run"] >= 3).astype(int)

        g["res_pred_type"] = np.where(g["untagged_alert"] == 1, "untagged_spend",
                              np.where(g["runaway_alert"] == 1, "runaway_usage",
                              np.where(g["idle_alert"] == 1, "idle_resource", "none")))
        g["res_alert"] = ((g["runaway_alert"] == 1) | (g["idle_alert"] == 1) |
                          (g["untagged_alert"] == 1)).astype(int)
        g["res_conf"] = np.where(
            g["untagged_alert"] == 1, "HIGH",
            np.where((g["runaway_alert"] == 1) & (g["weekend_ratio_14d"] > 0.98), "HIGH",
            np.where(g["idle_alert"] == 1, "HIGH",
            np.where(g["res_alert"] == 1, "MEDIUM", "NONE"))))
        out.append(g)
    return pd.concat(out, ignore_index=True)


# ─── SECTION 4 — PANEL RULES ────────────────────────────────────────────────
def apply_panel_rules(feat: pd.DataFrame) -> pd.DataFrame:
    C = CONSTANTS; f = feat.copy()
    # per-group observed-day index (0-based): how many prior days of history exist
    f["group_hist_days"] = f.groupby(
        ["linked_account_name", "service_code"]).cumcount()
    has_baseline = f["group_hist_days"] >= C["PANEL_MIN_HISTORY"]
    f["rule_untagged"] = ((f["untagged_cost"] >= C["UNTAGGED_MIN_COST"]) &
                          (f.groupby(["linked_account_name", "service_code"]).cumcount() >= 3)).astype(int)
    spike_cand = ((f["spike_ratio"] >= C["SPIKE_RATIO"]) &
                  (f["cost"] >= C["SPIKE_MIN_ABS"])).fillna(False)
    f["spike_candidate"] = spike_cand
    ss = []
    for _, g in f.groupby(["linked_account_name", "service_code"]):
        g = g.sort_values("date")
        g["spike_sustained_days"] = _consecutive_true(g["spike_candidate"].values)
        ss.append(g)
    f = pd.concat(ss, ignore_index=True)
    f["rule_spike"] = ((f["spike_candidate"]) &
                       (f["spike_sustained_days"] >= C["SPIKE_SUSTAINED_DAYS"]) &
                       (f["group_hist_days"] >= C["PANEL_MIN_HISTORY"])).astype(int)
    f["rule_drift"] = ((f["drift_sustained_days"] >= C["DRIFT_SUSTAINED_DAYS"]) &
                       (f["drift_ratio"] > C["DRIFT_RATIO"]) &
                       (f["group_hist_days"] >= C["PANEL_MIN_HISTORY"])).astype(int)
    return f


# ─── SECTION 5 — ISOLATION FOREST ───────────────────────────────────────────
IF_FEATURES = {
    "spike":   ["spike_ratio", "robust_z_score", "rate_of_change", "stl_residual"],
    "drift":   ["drift_ratio", "drift_sustained_days", "cusum_pos", "stl_trend"],
}
IF_CONTAM = {"spike": "IF_CONTAM_SPIKE", "drift": "IF_CONTAM_DRIFT"}


def train_isolation_forests(feat: pd.DataFrame):
    C = CONSTANTS; models = {}
    for typ, cols in IF_FEATURES.items():
        X = feat[cols].replace([np.inf, -np.inf], np.nan).fillna(0.0).values
        m = IsolationForest(contamination=CONSTANTS[IF_CONTAM[typ]],
                            random_state=C["RANDOM_STATE"], n_estimators=200)
        m.fit(X); models[typ] = (m, cols)
    return models


def score_isolation_forests(feat: pd.DataFrame, models) -> pd.DataFrame:
    f = feat.copy()
    for typ, (m, cols) in models.items():
        X = f[cols].replace([np.inf, -np.inf], np.nan).fillna(0.0).values
        f[f"if_{typ}"] = _norm(-m.score_samples(X))
    return f


# ─── SECTION 6 — FUSION + PERSISTENCE ───────────────────────────────────────
def fuse(feat: pd.DataFrame, res_alerts: pd.DataFrame):
    C = CONSTANTS; f = feat.copy()

    def tier(row):
        if row["rule_drift"]:
            return "gradual_drift", ("HIGH" if row.get("if_drift", 0) > C["IF_SCORE_HI"] else "MEDIUM")
        if row["rule_spike"]:
            return "sudden_spike", ("HIGH" if row.get("if_spike", 0) > C["IF_SCORE_HI"] else "MEDIUM")
        return "none", "NONE"
    tt = f.apply(tier, axis=1, result_type="expand")
    f["pred_type"] = tt[0]; f["confidence"] = tt[1]
    f["raw_alert"] = f["confidence"].isin(["HIGH", "MEDIUM"]).astype(int)

    fired = []
    for _, g in f.groupby(["linked_account_name", "service_code"]):
        g = g.sort_values("date")
        run = _consecutive_true(g["raw_alert"].values)
        # persistence N=2 removes single-day noise; but rules that already carry a
        # multi-day duration requirement (spike>=5d, drift>=14d, untagged) are
        # self-confirmed and must not be double-gated.
        self_confirmed = g["pred_type"].isin(
            ["sudden_spike", "gradual_drift"]).values
        g["alert_fired"] = (((run >= C["PERSISTENCE_N"]) | self_confirmed) &
                            (g["raw_alert"] == 1)).astype(int)
        fired.append(g)
    f = pd.concat(fired, ignore_index=True)

    ra = res_alerts[res_alerts["res_alert"] == 1].copy()
    ra = ra.rename(columns={"res_pred_type": "pred_type", "res_conf": "confidence"})
    ra["raw_alert"] = 1; ra["alert_fired"] = 1
    ra = ra[["linked_account_name", "service_code", "resource_id", "date",
             "cost", "pred_type", "confidence", "raw_alert", "alert_fired"]]
    f["resource_id"] = None
    merged = pd.concat([f, ra], ignore_index=True, sort=False)
    return merged, f, res_alerts


# ─── SECTION 7 — EVENT-LEVEL EVALUATION ─────────────────────────────────────
def evaluate_events(fired_all: pd.DataFrame, labels: pd.DataFrame):
    C = CONSTANTS
    lab = labels.copy()
    lab["start_date"] = pd.to_datetime(lab["start_date"])
    lab["end_date"] = pd.to_datetime(lab["end_date"])
    # resource_ids belonging to each labelled event
    ev_res = (lab.groupby(["anomaly_id"])["resource_id"]
                 .apply(lambda s: set(str(x) for x in s.dropna())).to_dict())
    events = (lab.groupby(["anomaly_id", "label", "anomaly_type",
                           "linked_account_name", "service"])
                 .agg(start_date=("start_date", "min"),
                      end_date=("end_date", "max")).reset_index())
    RESOURCE_TYPES = {"idle_resource", "runaway_usage", "untagged_spend"}
    rows = []
    for _, ev in events.iterrows():
        win = ((fired_all["date"] >= ev["start_date"]) &
               (fired_all["date"] <= ev["end_date"] + pd.Timedelta(days=C["GRACE_DAYS"])) &
               (fired_all["alert_fired"] == 1))
        same_cell = ((fired_all["linked_account_name"] == ev["linked_account_name"]) &
                     (fired_all["service_code"] == ev["service"]))
        # resource-grain alerts must match the event's specific resource_id;
        # panel-grain alerts (spike/drift) match at account x service.
        is_res_alert = fired_all["pred_type"].isin(RESOURCE_TYPES) & fired_all["resource_id"].notna()
        rids = ev_res.get(ev["anomaly_id"], set())
        res_match = is_res_alert & fired_all["resource_id"].astype(str).isin(rids)
        panel_match = (~is_res_alert) & same_cell
        hits = fired_all[win & (res_match | panel_match)].sort_values("date")
        detected = len(hits) > 0
        first_alert = hits["date"].min() if detected else pd.NaT
        delay = int((first_alert - ev["start_date"]).days) if detected else None
        pred_type = hits["pred_type"].mode().iat[0] if detected else "—"
        conf = ("HIGH" if detected and (hits["confidence"] == "HIGH").any()
                else ("MEDIUM" if detected else "—"))
        rows.append({**ev.to_dict(), "detected": detected, "first_alert": first_alert,
                     "delay": delay, "pred_type": pred_type, "confidence": conf})
    res = pd.DataFrame(rows)
    anom, ben = res[res.label == "anomaly"], res[res.label == "benign"]
    TP, FN = int(anom.detected.sum()), int((~anom.detected).sum())
    FP, TN = int(ben.detected.sum()), int((~ben.detected).sum())
    prec = TP/(TP+FP) if TP+FP else 0.0
    rec = TP/(TP+FN) if TP+FN else 0.0
    f1 = 2*prec*rec/(prec+rec) if prec+rec else 0.0
    fpr = FP/(FP+TN) if FP+TN else 0.0
    return res, {"TP": TP, "FP": FP, "FN": FN, "TN": TN,
                 "precision": prec, "recall": rec, "f1": f1, "fpr": fpr}


# ─── ORCHESTRATION ──────────────────────────────────────────────────────────
@dataclass
class FinOpsWatch:
    models: dict = field(default_factory=dict)

    def _core(self, ce, cur, metrics, fit: bool):
        panel = build_panel(ce)
        pf = engineer_panel_features(panel, cur)
        pf = apply_panel_rules(pf)
        if fit:
            self.models = train_isolation_forests(pf)
        pf = score_isolation_forests(pf, self.models)
        rmet = build_resource_metric_daily(metrics)
        rf = engineer_resource_features(cur, rmet)
        res_alerts = detect_resource_alerts(rf)
        fired_all, panel_fired, res_alerts = fuse(pf, res_alerts)
        return {"fired_all": fired_all, "panel": panel_fired,
                "res_alerts": res_alerts, "rf": rf}

    def fit_transform(self, ce, cur, metrics):
        return self._core(ce, cur, metrics, fit=True)

    def transform(self, ce, cur, metrics):
        return self._core(ce, cur, metrics, fit=False)


def run_pipeline(data_dir: str):
    ce, cur, metrics = load_sources(data_dir)
    fw = FinOpsWatch()
    core = fw.fit_transform(ce, cur, metrics)
    labels = pd.read_csv(f"{data_dir}/anomaly_labels_full.csv")
    res, m = evaluate_events(core["fired_all"], labels)
    return {"fw": fw, **core, "eval": res, "metrics": m,
            "ce": ce, "cur": cur, "metrics_df": metrics, "labels": labels}


if __name__ == "__main__":
    out = run_pipeline("/home/claude/files/data")
    r, m = out["eval"], out["metrics"]
    print(r[["anomaly_id", "label", "anomaly_type", "detected", "first_alert",
             "delay", "pred_type", "confidence"]].to_string(index=False))
    print("\nMETRICS:", {k: round(v, 3) if isinstance(v, float) else v for k, v in m.items()})
