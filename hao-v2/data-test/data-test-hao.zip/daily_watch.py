"""
FinOps Watch — 24h daily-cadence detection simulation on June-2026 forecast data.

Strategy:
  1. FIT the pipeline once on the 3-month backtest (Mar–May) → frozen IsolationForests.
  2. Concatenate backtest history + forecast month so rolling features have warm-up.
  3. Replay June day-by-day. Each 24h tick t: run .transform() on all data up to day t,
     collect alerts whose date == t (i.e. newly observable that day) → emit as the
     day's alert batch. Track first-seen alerts per (account, service, resource, type).
  4. Evaluate against forecast ground truth; produce per-event detection summary.
"""
import pandas as pd, numpy as np
from datetime import timedelta
from finops_watch import FinOpsWatch, load_sources, evaluate_events

pd.set_option("display.width", 200)

BACK = "/home/claude/files/data"
FC   = "/home/claude/forecast_data"

# ── load ────────────────────────────────────────────────────────────────────
ce_b, cur_b, met_b = load_sources(BACK)
ce_f, cur_f, met_f = load_sources(FC)
labels_f = pd.read_csv(f"{FC}/anomaly_labels_full.csv")

# 1) FIT on backtest (frozen models)
fw = FinOpsWatch()
fw.fit_transform(ce_b, cur_b, met_b)

# 2) combined history (backtest warm-up + forecast)
ce_all  = pd.concat([ce_b,  ce_f ], ignore_index=True)
cur_all = pd.concat([cur_b, cur_f], ignore_index=True)
met_all = pd.concat([met_b, met_f], ignore_index=True)

june_days = sorted(d for d in pd.to_datetime(ce_f["date"]).dt.normalize().unique()
                   if d >= pd.Timestamp("2026-06-01"))

# 3) day-by-day replay
seen = {}                # key -> first date fired
daily_log = []           # (day, n_new, list-of-alerts)
alert_rows = []          # every newly-fired alert row

def akey(r):
    return (r["linked_account_name"], r["service_code"],
            r.get("resource_id") or "-", r["pred_type"])

for day in june_days:
    day = pd.Timestamp(day)
    ce_t  = ce_all [pd.to_datetime(ce_all ["date"]).dt.normalize() <= day]
    cur_t = cur_all[pd.to_datetime(cur_all["date"]).dt.normalize() <= day]
    met_t = met_all[pd.to_datetime(met_all["date"]).dt.normalize() <= day]

    core = fw.transform(ce_t, cur_t, met_t)
    fired = core["fired_all"]
    fired = fired[fired["alert_fired"] == 1].copy()
    fired["date"] = pd.to_datetime(fired["date"]).dt.normalize()

    todays = fired[fired["date"] == day]
    new_today = []
    for _, r in todays.iterrows():
        k = akey(r)
        if k not in seen:
            seen[k] = day
            rec = {"day": day.date().isoformat(),
                   "account": r["linked_account_name"],
                   "service": r["service_code"],
                   "resource": r.get("resource_id") or "-",
                   "type": r["pred_type"],
                   "confidence": r["confidence"],
                   "cost": round(float(r.get("cost", 0) or 0), 2)}
            new_today.append(rec); alert_rows.append(rec)
    daily_log.append((day.date().isoformat(), len(new_today), new_today))

# ── daily cadence print ──────────────────────────────────────────────────────
print("="*74)
print("24-HOUR DAILY DETECTION CADENCE — June 2026 forecast")
print("="*74)
for d, n, alerts in daily_log:
    if n == 0:
        print(f"[{d}] tick — no new alerts")
    else:
        print(f"[{d}] tick — {n} NEW ALERT(S):")
        for a in alerts:
            print(f"      ! {a['type']:<14} {a['account']}/{a['service']}"
                  f"  res={a['resource']}  conf={a['confidence']}  ${a['cost']}")

# ── evaluate vs forecast ground truth ────────────────────────────────────────
# rebuild final full-month state for event-level scoring
core_full = fw.transform(ce_all, cur_all, met_all)
# restrict fired alerts to June only for fair matching
ff = core_full["fired_all"].copy()
ff["date"] = pd.to_datetime(ff["date"]).dt.normalize()
ff = ff[ff["date"] >= june_days[0]]
core_full["fired_all"] = ff

res, m = evaluate_events(core_full["fired_all"], labels_f)

print("\n" + "="*74)
print("EVENT-LEVEL DETECTION RESULT (June forecast)")
print("="*74)
print(res[["anomaly_id", "label", "anomaly_type", "detected",
           "first_alert", "delay", "pred_type", "confidence"]].to_string(index=False))
print("\nMETRICS:", {k: round(v, 3) if isinstance(v, float) else v for k, v in m.items()})

# persist artifacts for the review file
res.to_csv("/home/claude/forecast_eval.csv", index=False)
pd.DataFrame(alert_rows).to_csv("/home/claude/forecast_daily_alerts.csv", index=False)
import json
json.dump({"metrics": m,
           "daily": [{"day": d, "n_new": n, "alerts": a} for d, n, a in daily_log]},
          open("/home/claude/forecast_run.json", "w"), indent=2, default=str)
print("\nartifacts: forecast_eval.csv, forecast_daily_alerts.csv, forecast_run.json")
